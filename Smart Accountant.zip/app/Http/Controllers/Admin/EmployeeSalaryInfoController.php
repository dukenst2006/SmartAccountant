<?php

namespace App\Http\Controllers;

use App\EmployeeSalaryInfo;
use Illuminate\Http\Request;

class EmployeeSalaryInfoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\EmployeeSalaryInfo  $employeeSalaryInfo
     * @return \Illuminate\Http\Response
     */
    public function show(EmployeeSalaryInfo $employeeSalaryInfo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\EmployeeSalaryInfo  $employeeSalaryInfo
     * @return \Illuminate\Http\Response
     */
    public function edit(EmployeeSalaryInfo $employeeSalaryInfo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\EmployeeSalaryInfo  $employeeSalaryInfo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, EmployeeSalaryInfo $employeeSalaryInfo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\EmployeeSalaryInfo  $employeeSalaryInfo
     * @return \Illuminate\Http\Response
     */
    public function destroy(EmployeeSalaryInfo $employeeSalaryInfo)
    {
        //
    }
}
