<?php


namespace App\Repositories;


class SafeRepository
{

}
