<?php


namespace App\Repositories;


class ProductSubCategoryRepository
{

}
