<?php


namespace App\Repositories;


class SupervisorRepository
{

}
