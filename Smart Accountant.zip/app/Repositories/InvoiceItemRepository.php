<?php


namespace App\Repositories;


class InvoiceItemRepository
{

}
