<?php


namespace App\Repositories;


class InvloiceRepository
{

}
