<?php


namespace App\Repositories;


class MarketplaceRepository
{

}
