<?php


namespace App\Repositories;


class ProductCategoryRepository
{

}
