<?php


namespace App\Repositories;


class StockRepository
{

}
