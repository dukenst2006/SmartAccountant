<?php


namespace App\Repositories;


class InvoiceRepository
{

public function xxx(){

}

}
