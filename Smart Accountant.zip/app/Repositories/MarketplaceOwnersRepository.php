<?php


namespace App\Repositories;


class MarketplaceOwnersRepository
{

}
