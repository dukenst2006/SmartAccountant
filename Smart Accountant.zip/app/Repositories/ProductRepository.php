<?php


namespace App\Repositories;


class ProductRepository
{

}
