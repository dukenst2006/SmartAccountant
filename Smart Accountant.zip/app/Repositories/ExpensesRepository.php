<?php


namespace App\Repositories;


class ExpensesRepository
{

}
