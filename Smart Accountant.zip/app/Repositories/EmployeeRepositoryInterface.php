<?php


namespace App\Repositories;


interface EmployeeRepositoryInterface
{

    public function all();  //Getting All Employees
    public function GetEmployeeStatics();

}
