<?php


namespace App\Repositories;


class SystemAdminRepository
{

}
