<!-- Productcategoryid Field -->
<div class="form-group">
    {!! Form::label('ProductCategoryID', 'Productcategoryid:') !!}
    <p>{{ $productSubCategory->ProductCategoryID }}</p>
</div>

<!-- Name Field -->
<div class="form-group">
    {!! Form::label('Name', 'Name:') !!}
    <p>{{ $productSubCategory->Name }}</p>
</div>

