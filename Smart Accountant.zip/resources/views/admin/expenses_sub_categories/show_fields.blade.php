<!-- Expensescategoryid Field -->
<div class="form-group">
    {!! Form::label('ExpensesCategoryID', 'Expensescategoryid:') !!}
    <p>{{ $expensesSubCategory->ExpensesCategoryID }}</p>
</div>

<!-- Name Field -->
<div class="form-group">
    {!! Form::label('Name', 'Name:') !!}
    <p>{{ $expensesSubCategory->Name }}</p>
</div>

