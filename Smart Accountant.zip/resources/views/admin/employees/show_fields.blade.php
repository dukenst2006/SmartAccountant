<!-- Userid Field -->
<div class="form-group">
    {!! Form::label('UserID', 'Userid:') !!}
    <p>{{ $employee->UserID }}</p>
</div>

<!-- Marketplaceid Field -->
<div class="form-group">
    {!! Form::label('MarketplaceID', 'Marketplaceid:') !!}
    <p>{{ $employee->MarketplaceID }}</p>
</div>

<!-- Marketplaceownerid Field -->
<div class="form-group">
    {!! Form::label('MarketplaceOwnerID', 'Marketplaceownerid:') !!}
    <p>{{ $employee->MarketplaceOwnerID }}</p>
</div>

<!-- Nationality Field -->
<div class="form-group">
    {!! Form::label('Nationality', 'Nationality:') !!}
    <p>{{ $employee->Nationality }}</p>
</div>

<!-- Jobtitle Field -->
<div class="form-group">
    {!! Form::label('JobTitle', 'Jobtitle:') !!}
    <p>{{ $employee->JobTitle }}</p>
</div>

<!-- Nationalid Field -->
<div class="form-group">
    {!! Form::label('NationalID', 'Nationalid:') !!}
    <p>{{ $employee->NationalID }}</p>
</div>

<!-- Phonenumber Field -->
<div class="form-group">
    {!! Form::label('PhoneNumber', 'Phonenumber:') !!}
    <p>{{ $employee->PhoneNumber }}</p>
</div>

<!-- Profileimage Field -->
<div class="form-group">
    {!! Form::label('ProfileImage', 'Profileimage:') !!}
    <p>{{ $employee->ProfileImage }}</p>
</div>

<!-- Identityimage Field -->
<div class="form-group">
    {!! Form::label('IdentityImage', 'Identityimage:') !!}
    <p>{{ $employee->IdentityImage }}</p>
</div>

<!-- Employmentcontractimage Field -->
<div class="form-group">
    {!! Form::label('EmploymentContractImage', 'Employmentcontractimage:') !!}
    <p>{{ $employee->EmploymentContractImage }}</p>
</div>

<!-- Iban Field -->
<div class="form-group">
    {!! Form::label('IBAN', 'Iban:') !!}
    <p>{{ $employee->IBAN }}</p>
</div>

<!-- Sex Field -->
<div class="form-group">
    {!! Form::label('Sex', 'Sex:') !!}
    <p>{{ $employee->Sex }}</p>
</div>

<!-- Salary Field -->
<div class="form-group">
    {!! Form::label('Salary', 'Salary:') !!}
    <p>{{ $employee->Salary }}</p>
</div>

