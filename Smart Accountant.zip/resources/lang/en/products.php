<?php
return [
    'quantity' => 'Quantity',
    'quantity_type' => 'Quantity Type',
    'buying_price' => 'Buying Price',
    'selling_price' => 'Selling Price',
    'lower_price' => 'Lower Price',
    'expires_at' => 'Expires at',
    'bar_code' => 'Barcode',
    'can_sell_unavailable' => 'Sell when not available',
    'piece' => 'Piece',
    'carton' => 'Carton',
    'grain' => 'Grain',
    "Products" => "Products",
    'branch_id'=>'Branch name',

];