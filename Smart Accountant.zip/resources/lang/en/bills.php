<?php



return [
    'tax_number' => 'Tax number',
    'bill_number' => "Bill Number",
    'bill_date' => "Bill Date",
    'products_count' => "Products Count",
    'discount' => "Discount",
    'branch_name' => 'Branch Name',
    'employee name' =>  'Employee',
    'bill way' =>      'Bill Way',
    'bill statue' =>      'Bill Statue',
    'cash' =>       'Cash',
    'credit' =>     'Credit Card',
    'add to bill' =>     'Add to Bill',
    'remove'    =>     'Remove',
    'products'  =>     'Products',
    'total'         =>     'Total',
    'bill value'        =>'Bill Value',
    'discount value'    =>'Discount Value',
    'payed value'   =>'Payed Value',
    'reward'    =>  'Gain',
];
