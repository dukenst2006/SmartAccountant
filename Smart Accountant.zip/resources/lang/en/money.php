<?php
return [
    'title' =>  'Money Locker',
    'choose date' => 'Choose a Date',
    'from'=>'From',
    'to'=>'To',
    'selling_price'=>'Selling Price',
    'buying_price'=>'Buying Price',
    'lose'=>'Losing',
    'paid'=>'Paid',
    'all'=>'All',
    'search'=>'Search',
    'total this time'=>'Total in this Time',
];
