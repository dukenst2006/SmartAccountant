<?php

return array (
  'singular' => 'Supplier',
  'plural' => 'Suppliers',
  'fields' => 
  array (
    'id' => 'Id',
    'MarketplaceOwnerID' => 'Marketplaceownerid',
    'Name' => 'Name',
    'Company' => 'Company',
    'PhoneNumber' => 'Phonenumber',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
