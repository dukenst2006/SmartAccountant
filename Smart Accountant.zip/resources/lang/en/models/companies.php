<?php

return array (
  'singular' => 'Company',
  'plural' => 'Companies',
  'fields' => 
  array (
    'id' => 'Id',
    'Name' => 'Name',
    'Address' => 'Address',
    'Country' => 'Country',
    'PhoneNumber' => 'Phonenumber',
    'Description' => 'Description',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
