<?php

return [
    'expenses_category' => 'Expenses categories',
    'expenses_subCat' => 'Expenses subcategories',
    'expense_type' => 'Type',
    'main_cat'=>'Main category',
    'sub_cat'=>'Subcategory'




];