<?php
return [
    'admins'    =>  'Admin Count',
    'employees' =>  'Employees Count',
    'branches'  =>  'Branches Count',
    'bills'     =>  'Bills Count',
    'expensive' =>  'Expenses',
    'Rankings'  =>  'Ranks',
    'Statics'   =>  'Statics',
];
