<?php
return [
    'title' =>  'الخزنة',
    'choose date' => 'اختار تاريخ',
    'from'=>'من',
    'to'=>'الي',
    'selling_price'=>'سعر البيع',
    'buying_price'=>'سعر الشراء',
    'lose'=>'الخسائر',
    'paid'=>'المدفوع',
    'all'=>'الكل',
    'search'=>'بحث',
    'total this time'=>'الاجمالي في هذا الوقت',
];
