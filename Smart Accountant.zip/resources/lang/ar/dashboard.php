<?php
return [
    'admins'    =>  'عدد المشرفين',
    'employees' =>  'عدد الموظفين',
    'branches'  =>  'عدد الفروع',
    'bills'     =>  'الفواتير',
    'expensive' =>  'المصروفات',
    'Rankings'  =>  'تصنيفات',
    'Statics'   =>  'الاحصائيات'
];
