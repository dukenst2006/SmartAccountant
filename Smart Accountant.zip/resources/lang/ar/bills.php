<?php


return [
    'tax_number' => 'الرقم الضريبي',
    'bill_number' => "رقم الفاتورة",
    'bill_date' => "تاريخ الفاتورة",
    'products_count' => "عدد الاصناف",
    'discount' => "الخصم",
    'branch_name' => 'اسم الفرع',
    'employee name' =>  'اسم الموظف',
    'bill way' =>      'طريقةالدفع',
    'bill statue' =>      'حالة الفاتورة',
    'cash' =>       'كاش',
    'credit' =>     'بطاقة ائتمانية',
    'add to bill' =>     'اضافة الي الفاتورة',
    'remove'    =>     'ازالةْ',
    'products'  =>     'الاصناف',
    'total'         =>     'الاجمالي',
    'bill value'        =>'قيمة الفاتورة',
    'discount value'    =>'قيمة الخصم',
    'payed value'   =>'المبلغ المدفوع',
    'reward'    =>  'الربح',
];
