<?php
return [
    'quantity' => 'الكمية',
    'quantity_type' => 'نوع الكمية',
    'buying_price' => 'سعر البيع',
    'selling_price' => 'سعر الشراء',
    'lower_price' => 'سعر منخفض',
    'expires_at' => 'تاريخ الانتهاء',
    'bar_code' => 'الباركود',
    'can_sell_unavailable' => 'البيع عن عدم التوافر',
    'piece' => 'قطعة',
    'carton' => 'كرتونة',
    'grain' => 'حبة',
    "Products" => "منتجات",
    'branch_id'=>'اسم الفرع',


];