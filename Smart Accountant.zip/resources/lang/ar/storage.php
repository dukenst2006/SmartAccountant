<?php
return [
    'title' => 'الخزينة',
    'total payed cash' => 'اجمالي المبيعات كاش',
    'total payed credit' => 'اجمالي المبيعات الائتمانية',
    'total payed' => 'اجمالي المبيعات',
    'total bought' => 'اجمالي الشراء',
    'costs' => 'مصروفات',
    'rest' => 'الارباح',
    'filtered' => 'الصافي',
];
