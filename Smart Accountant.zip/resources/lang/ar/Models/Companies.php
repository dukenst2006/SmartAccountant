<?php
use Yajra\DataTables\Html\Column;
return [
    'Name' => 'أسم الشركة',
    'Address'=>'عنوان الشركة',
    'Country'=>'البلد',
    'PhoneNumber'=>'رقم الجوال',
    'Description'=>'وصف',
];
