<?php

use Yajra\DataTables\Html\Column;

return [
    'PhoneNumber' => 'رقم الجوال',

];
