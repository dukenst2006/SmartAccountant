<!-- Userid Field -->
<div class="form-group">
    {!! Form::label('UserID', 'Userid:') !!}
    <p>{{ $supervisor->UserID }}</p>
</div>

<!-- Marketplaceownerid Field -->
<div class="form-group">
    {!! Form::label('MarketplaceOwnerID', 'Marketplaceownerid:') !!}
    <p>{{ $supervisor->MarketplaceOwnerID }}</p>
</div>

<!-- Phonenumber Field -->
<div class="form-group">
    {!! Form::label('PhoneNumber', 'Phonenumber:') !!}
    <p>{{ $supervisor->PhoneNumber }}</p>
</div>

