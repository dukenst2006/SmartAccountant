<!-- Marketplacesid Field -->
<div class="form-group">
    {!! Form::label('MarketplacesID', 'Marketplacesid:') !!}
    <p>{{ $productCategory->MarketplacesID }}</p>
</div>

<!-- Name Field -->
<div class="form-group">
    {!! Form::label('Name', 'Name:') !!}
    <p>{{ $productCategory->Name }}</p>
</div>

