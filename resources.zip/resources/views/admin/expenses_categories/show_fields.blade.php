<!-- Marketplacesid Field -->
<div class="form-group">
    {!! Form::label('MarketplacesID', 'Marketplacesid:') !!}
    <p>{{ $expensesCategory->MarketplacesID }}</p>
</div>

<!-- Name Field -->
<div class="form-group">
    {!! Form::label('Name', 'Name:') !!}
    <p>{{ $expensesCategory->Name }}</p>
</div>

