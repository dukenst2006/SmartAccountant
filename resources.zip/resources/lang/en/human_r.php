<?php
return [
    'title'             => 'Human Resource',
    'all_employees'     => 'All Employees',
    'stoned_employees'  => 'Stoned Employees',
    'active_employees'  => 'Activated Employees',
    'search in brench'  => 'Search In Branch',
    'salaries'          => 'Salaries',
    'salaries in brench'=> 'Total Salaries in A Branch',
    'brench name'       => 'Branch Name',
    'employees count'   => 'Count of Employees',
    'all salaries'      => 'Total Salaries in All Branches',
];
