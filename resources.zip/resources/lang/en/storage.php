<?php
return [
    'title' => 'Storage',
    'total payed cash' => 'Total Payed Cash',
    'total payed credit' => 'Total Payed Credit',
    'total payed' => 'Total Selling',
    'total bought' => 'Total Buying',
    'costs' => 'Expenses',
    'rest' => 'Gain',
    'filtered' => 'Rest',
];
