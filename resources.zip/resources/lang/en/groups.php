<?php
return [
    'main_group' => 'Main group',
    'sub_group' => 'Sub group',
    'group_mange' => 'Groups management',

];