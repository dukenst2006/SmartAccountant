<?php
return [
    'name' => 'Name',
    'selling_price' => 'Selling Price',
    'quantity' => 'Quantity',
];
