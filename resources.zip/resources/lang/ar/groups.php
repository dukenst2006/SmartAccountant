<?php
return [
    'main_group' => 'الصنف الرئيسي',
    'sub_group' => 'الصنف الفرعي',
    'group_mange' => 'ادارة الاصناف',

];