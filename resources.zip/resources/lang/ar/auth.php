<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'لم تتطابق بيانات الدخول لاي مستخدم لدينا',
    'throttle' => 'محاولات دخول خطا . فضلا حاول الدخول مرة اخري خلال :seconds ثانية.',

];
