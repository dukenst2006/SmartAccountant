<?php
return [
    'title'             => 'الموارد البشرية',
    'all_employees'     => 'كل الموظفين',
    'stoned_employees'  => 'الموظفون الموقوفون',
    'active_employees'  => 'الموظفون الفعالون',
    'search in brench'  => 'البحث في فرع',
    'salaries'          => 'الرواتب',
    'salaries in brench'=> 'اجمالي الرواتب في الفرع',
    'brench name'       => 'اسم الفرع',
    'employees count'   => 'عدد الموظفين',
    'all salaries'      => 'اجمالي الرواتب في كل الفروع',
];
