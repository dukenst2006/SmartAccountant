<?php
return [
    'name' => 'الاسم',
    'selling_price' => 'سعر البيع',
    'quantity' => 'الكمية',
];
