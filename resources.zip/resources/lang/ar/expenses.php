<?php

return [
    'expenses_category'=>'اقسام المصروفات',
    'expenses_subCat' => 'الاقسام الفرعية',
    'expense_type'=>'الصنف',
    'main_cat'=>'القسم الرئيسي',
    'sub_cat'=>'القسم الفرعي',








];