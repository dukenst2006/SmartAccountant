<?php

use Yajra\DataTables\Html\Column;

return [
    'Name' => 'الأسم',
    'PhoneNumber' => 'رقم الجوال',
    'Description' => 'وصف',
    "Company"       =>  "الشركة"
];
