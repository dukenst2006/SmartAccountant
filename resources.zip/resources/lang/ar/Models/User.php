<?php

use Yajra\DataTables\Html\Column;

return [

    'Name' => 'الأسم',
    'Email' => 'الأيميل',
    'Password' => 'الباسورد'

];
