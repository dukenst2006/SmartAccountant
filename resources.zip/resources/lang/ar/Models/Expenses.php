<?php
use Yajra\DataTables\Html\Column;
return [



        'Name' =>'الأسم',
        'Price' =>'المبلغ',
        'Description' =>'الوصف',
        'Date' =>'التاريخ',

];
