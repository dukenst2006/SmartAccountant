<?php

use Yajra\DataTables\Html\Column;

return [
    'Nationality' => 'الجنسيه',
    'JobTitle' => 'الأسم الوظيفي',
    'NationalID' => 'الرقم الوطني',
    'PhoneNumber' => 'رقم الجوال',
    'ProfileImage' => 'الصورة الشخصية',
    'IdentityImage' => 'صورة الهوية',
    'EmploymentContractImage' => 'صورة عقد التوظيف',
    'IBAN' => 'رقم الحساب البنكي',
    'Sex' => 'الجنس',
    'Salary' => 'الراتب'
];
