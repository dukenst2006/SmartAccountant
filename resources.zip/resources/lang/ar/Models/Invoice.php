<?php

use Yajra\DataTables\Html\Column;

return [
    'File' => 'صوره/ملف',
    'Total' => 'الاجمالي',
    'Paid' => 'المدفوع',
    'PaymentTypeID' => 'طريقة الدفع',
    'Name' => 'الأسم',
];
