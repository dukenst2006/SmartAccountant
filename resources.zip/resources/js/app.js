// import VueRouter from "vue-router";
// import Vue from "vue";
// import routes from './routes'
//
//
// Vue.use(VueRouter);



require('./bootstrap');
//
// window.Vue = require('vue');
//
// let app = new Vue({
//     el: '#app',
//
//
//     router: new VueRouter(routes)
//
// });
